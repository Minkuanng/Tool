# KuanDev Prenium v1.2 — Garena Auto Register

## Mới trong v1.2

- **Proxy auto-auth**: tự điền user/pass của proxy → không hiện hộp thoại nhập tay
- **Menu nhỏ gọn**: width ~200px, gọn hơn rõ

## Username / Email

- Username: `ABCDEFG123` (7 HOA + 3 số)
- Email: `abcdefg123@mailforspam.net` (7 thường + 3 số)

## Proxy

Format mỗi dòng:
```
ip:port
ip:port:user:pass
```

Bật toggle → Shuffle → Save. Mỗi account xoay 1 proxy, credentials tự gửi cho browser.

## Cài đặt

1. Giải nén ZIP
2. `chrome://extensions` → Developer mode → Load unpacked
3. Chọn thư mục `garena-auto-register-extension`
4. Reload extension nếu đang cài bản cũ

## Cấu trúc

- `manifest.json` — MV3 + proxy + webRequestAuthProvider
- `background.js` — set proxy + onAuthRequired auto-fill
- `content.js` — UI + logic đăng ký
- `popup.html` / `popup.js`

document.getElementById('toggle-btn').addEventListener('click', async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return;

    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        // Toggle visibility of the injected UI
        const ui = document.getElementById('kuandev-ui');
        const toggle = document.getElementById('kuandev-toggle');
        if (ui) {
          const hidden = ui.style.display === 'none';
          ui.style.display = hidden ? '' : 'none';
          try {
            localStorage.setItem('kuandev_pro_hidden', hidden ? '0' : '1');
          } catch {}
        } else if (toggle) {
          toggle.click();
        } else {
          alert('Panel chưa sẵn sàng. Hãy reload trang rồi thử lại.');
        }
      }
    });
    window.close();
  } catch (e) {
    console.error(e);
    document.getElementById('status').textContent = 'Lỗi (cần reload trang)';
    document.getElementById('status').style.color = '#f87171';
  }
});

// Simple status check
chrome.tabs.query({ active: true, currentWindow: true }, async ([tab]) => {
  if (!tab?.id) return;
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => !!document.getElementById('kuandev-ui')
    });
    const exists = results?.[0]?.result;
    document.getElementById('ui-status').textContent = exists ? 'Đã inject' : 'Chưa có (reload trang)';
    document.getElementById('ui-status').style.color = exists ? '#34d399' : '#fbbf24';
  } catch {
    document.getElementById('ui-status').textContent = 'Không kiểm tra được';
    document.getElementById('ui-status').style.color = '#a1a1aa';
  }
});

/**
 * KuanDev Prenium - Background Service Worker
 * Proxy rotation + auto-fill proxy username/password (không cần nhập tay)
 */

let currentAuth = null; // { username, password } | null

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'SET_PROXY') {
    if (msg.clear) {
      currentAuth = null;
      chrome.proxy.settings.clear({ scope: 'regular' }, () => {
        sendResponse({ ok: true, cleared: true });
      });
      return true;
    }

    const p = msg.proxy;
    if (!p || !p.host || !p.port) {
      sendResponse({ ok: false, error: 'invalid proxy' });
      return false;
    }

    // Lưu user/pass để tự điền khi browser yêu cầu auth
    if (p.user) {
      currentAuth = {
        username: String(p.user),
        password: String(p.pass || '')
      };
    } else {
      currentAuth = null;
    }

    const config = {
      mode: 'fixed_servers',
      rules: {
        singleProxy: {
          scheme: 'http',
          host: p.host,
          port: parseInt(p.port, 10)
        },
        bypassList: ['localhost', '127.0.0.1', '<local>']
      }
    };

    chrome.proxy.settings.set({ value: config, scope: 'regular' }, () => {
      if (chrome.runtime.lastError) {
        sendResponse({ ok: false, error: chrome.runtime.lastError.message });
      } else {
        sendResponse({
          ok: true,
          proxy: `${p.host}:${p.port}`,
          auth: !!currentAuth
        });
      }
    });

    return true;
  }

  if (msg.type === 'GET_PROXY') {
    chrome.proxy.settings.get({ incognito: false }, (details) => {
      sendResponse({ ok: true, details, hasAuth: !!currentAuth });
    });
    return true;
  }

  return false;
});

/**
 * Tự động cung cấp username/password proxy
 * → Trình duyệt không hiện hộp thoại nhập tay
 */
chrome.webRequest.onAuthRequired.addListener(
  (details, callback) => {
    if (currentAuth) {
      callback({
        authCredentials: {
          username: currentAuth.username,
          password: currentAuth.password
        }
      });
    } else {
      callback({}); // không có credentials
    }
  },
  { urls: ['<all_urls>'] },
  ['asyncBlocking']
);

chrome.runtime.onSuspend?.addListener(() => {
  currentAuth = null;
  chrome.proxy.settings.clear({ scope: 'regular' });
});
